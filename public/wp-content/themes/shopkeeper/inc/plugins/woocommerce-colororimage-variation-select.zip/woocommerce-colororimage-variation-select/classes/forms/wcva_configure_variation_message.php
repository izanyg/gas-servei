<div id="colored_variable_tab_data">

		
	<div id="message" class="inline notice woocommerce-message">
		<p><?php echo esc_html__('Please configure attributes and variations before configuring Swatches.','wcva'); ?></p>
				
    </div>
</div>